</main>

    <footer class="page-footer">
        <small>Sistema Conferentes PLUS • Versão 0.1</small>
    </footer>

    <script src="/assets/js/app.js"></script>
</body>
</html>
